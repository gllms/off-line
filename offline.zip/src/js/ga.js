var GA = GA || {}; GA.VERSION = "0.0.1"; GA.plugins = void 0; GA.custom = void 0;
GA.create = function (u, v, w, x, y) {
  function p() { requestAnimationFrame(p, c.canvas); if (void 0 === c._fps) q(), c.render(c.canvas, 0); else { var a = Date.now(), b = a - c._startTime; 1E3 < b && (b = c._frameDuration); c._startTime = a; for (c._lag += b; c._lag >= c._frameDuration;)z(), q(), c._lag -= c._frameDuration; c.render(c.canvas, c._lag / c._frameDuration) } } function z() { function a(b) { b._previousX = b.x; b._previousY = b.y; b.children && 0 < b.children.length && b.children.forEach(function (b) { a(b) }) } c.stage.children.forEach(function (b) { a(b) }) } function q() {
    if (0 <
      c.buttons.length) { c.canvas.style.cursor = "auto"; for (var a = c.buttons.length - 1; 0 <= a; a--) { var b = c.buttons[a]; b.update(c.pointer, c.canvas); "over" !== b.state && "down" !== b.state || b.stage || (c.canvas.style.cursor = "pointer") } } c.dragAndDrop && c.pointer.updateDragAndDrop(); c.state && !c.paused && c.state(); if (0 !== c.updateFunctions.length) for (a = 0; a < c.updateFunctions.length; a++)(0, c.updateFunctions[a])()
  } function l(a) {
    a.x = 0; a.y = 0; a.vx = 0; a.vy = 0; a.width = 0; a.height = 0; a.scaleX = 1; a.scaleY = 1; a.pivotX = .5; a.pivotY = .5; a.rotation =
      0; a.visible = !0; a.parent = void 0; a.stage = !1; a.shadow = !1; a.shadowColor = "rgba(100, 100, 100, 0.5)"; a.shadowOffsetX = 3; a.shadowOffsetY = 3; a.shadowBlur = 3; a.blendMode = void 0; a._alpha = 1; a._draggable = void 0; a._layer = 0; a._circular = !1; a._interactive = !1; a._previousX = void 0; a._previousY = void 0; a.children = []; a.addChild = function (b) { b.parent && b.parent.removeChild(b); b.parent = a; a.children.push(b) }; a.removeChild = function (b) {
        if (b.parent === a) a.children.splice(a.children.indexOf(b), 1); else throw Error(b + "is not a child of " +
          a);
      }; a.swapChildren = function (b, c) { var h = a.children.indexOf(b), g = a.children.indexOf(c); if (-1 !== h && -1 !== g) b.childIndex = g, c.childIndex = h, a.children[h] = c, a.children[g] = b; else throw Error(child + " Both objects must be a child of the caller " + a); }; a.add = function (b) { var c = Array.prototype.slice.call(arguments); 1 < c.length ? c.forEach(function (b) { a.addChild(b) }) : a.addChild(c[0]) }; a.remove = function (b) { var c = Array.prototype.slice.call(arguments); 1 < c.length ? c.forEach(function (b) { a.removeChild(b) }) : a.removeChild(c[0]) };
    a.setPosition = function (b, c) { a.x = b; a.y = c }; a.putCenter = function (b, c, e) { b.x = a.x + a.halfWidth - b.halfWidth + (c || 0); b.y = a.y + a.halfHeight - b.halfHeight + (e || 0); a.compensateForParentPosition(a, b) }; a.putTop = function (b, c, e) { b.x = a.x + a.halfWidth - b.halfWidth + (c || 0); b.y = a.y - b.height + (e || 0); a.compensateForParentPosition(a, b) }; a.putRight = function (b, c, e) { b.x = a.x + a.width + (c || 0); b.y = a.y + a.halfHeight - b.halfHeight + (e || 0); a.compensateForParentPosition(a, b) }; a.putBottom = function (b, c, e) {
      b.x = a.x + a.halfWidth - b.halfWidth + (c || 0);
      b.y = a.y + a.height + (e || 0); a.compensateForParentPosition(a, b)
    }; a.putLeft = function (b, c, e) { b.x = a.x - b.width + (c || 0); b.y = a.y + a.halfHeight - b.halfHeight + (e || 0); a.compensateForParentPosition(a, b) }; a.compensateForParentPosition = function (a, c) { if (0 !== c.parent.gx || 0 !== c.parent.gy) c.x -= a.gx, c.y -= a.gy }; Object.defineProperties(a, {
      gx: { get: function () { return this.parent ? this.x + this.parent.gx : this.x }, enumerable: !0, configurable: !0 }, gy: { get: function () { return this.parent ? this.y + this.parent.gy : this.y }, enumerable: !0, configurable: !0 },
      position: { get: function () { return { x: a.x, y: a.y } }, enumerable: !0, configurable: !0 }, alpha: { get: function () { return a.parent._alpha * a._alpha }, set: function (b) { a._alpha = b }, enumerable: !0, configurable: !0 }, halfWidth: { get: function () { return a.width / 2 }, enumerable: !0, configurable: !0 }, halfHeight: { get: function () { return a.height / 2 }, enumerable: !0, configurable: !0 }, centerX: { get: function () { return a.x + a.halfWidth }, enumerable: !0, configurable: !0 }, centerY: { get: function () { return a.y + a.halfHeight }, enumerable: !0, configurable: !0 },
      layer: { get: function () { return a._layer }, set: function (b) { a._layer = b; a.parent.children.sort(A) }, enumerable: !0, configurable: !0 }, circular: { get: function () { return a._circular }, set: function (b) { !0 === b && !1 === a._circular && (r(a), a._circular = !0); !1 === b && !0 === a._circular && (delete a.diameter, delete a.radius, a._circular = !1) }, enumerable: !0, configurable: !0 }, draggable: {
        get: function () { return a._draggable }, set: function (b) {
          !0 === b && (c.draggableSprites.push(a), a._draggable = !0, !1 === c.dragAndDrop && (c.dragAndDrop = !0)); !1 ===
            b && c.draggableSprites.splice(c.draggableSprites.indexOf(a), 1)
        }, enumerable: !0, configurable: !0
      }, interactive: { get: function () { return a._interactive }, set: function (b) { !0 === b && (t(a), a._interactive = !0); !1 === b && (c.buttons.splice(c.buttons.indexOf(a), 1), a._interactive = !1) }, enumerable: !0, configurable: !0 }, localBounds: { get: function () { return { x: 0, y: 0, width: a.width, height: a.height } }, enumerable: !0, configurable: !0 }, globalBounds: {
        get: function () { return rectangle = { x: a.gx, y: a.gy, width: a.gx + a.width, height: a.gy + a.height } },
        enumerable: !0, configurable: !0
      }, empty: { get: function () { return 0 === a.children.length ? !0 : !1 }, enumerable: !0, configurable: !0 }
    })
  } function r(a) { Object.defineProperties(a, { diameter: { get: function () { return a.width }, set: function (b) { a.width = b; a.height = b }, enumerable: !0, configurable: !0 }, radius: { get: function () { return a.width / 2 }, set: function (b) { a.width = 2 * b; a.height = 2 * b }, enumerable: !0, configurable: !0 } }) } function t(a) {
    a.press = a.press || void 0; a.release = a.release || void 0; a.over = a.over || void 0; a.out = a.out || void 0; a.tap =
      a.tap || void 0; a.state = "up"; a.action = ""; a.pressed = !1; a.enabled = !0; a.hoverOver = !1; c.buttons.push(a); a.update = function (b, h) {
        if (a.enabled) {
          var e = c.pointer.hitTestSprite(a); b.isUp && (a.state = "up", "button" === a.subtype && a.show(0)); e && (a.state = "over", a.frames && 3 === a.frames.length && "button" === a.subtype && a.show(1), b.isDown && (a.state = "down", "button" === a.subtype && (3 === a.frames.length ? a.show(2) : a.show(1)))); "down" !== a.state || a.pressed || (a.press && a.press(), a.pressed = !0, a.action = "pressed"); "over" === a.state && (a.pressed &&
            (a.release && a.release(), a.pressed = !1, a.action = "released", c.pointer.tapped && a.tap && a.tap()), a.hoverOver || (a.over && a.over(), a.hoverOver = !0)); "up" === a.state && (a.pressed && (a.release && a.release(), a.pressed = !1, a.action = "released"), a.hoverOver && (a.out && a.out(), a.hoverOver = !1))
        }
      }
  } function n(a) {
    var b = {}; b.code = a; b.isDown = !1; b.isUp = !0; b.press = void 0; b.release = void 0; b.downHandler = function (a) { a.keyCode === b.code && (b.isUp && b.press && b.press(), b.isDown = !0, b.isUp = !1); a.preventDefault() }; b.upHandler = function (a) {
      a.keyCode ===
        b.code && (b.isDown && b.release && b.release(), b.isDown = !1, b.isUp = !0); a.preventDefault()
    }; window.addEventListener("keydown", b.downHandler.bind(b), !1); window.addEventListener("keyup", b.upHandler.bind(b), !1); return b
  } function A(a, b) { return a.layer < b.layer ? -1 : 1 } var c = {}; c.canvas = document.createElement("canvas"); c.canvas.setAttribute("width", 1 * u); c.canvas.setAttribute("height", 1 * v); c.canvas.style.backgroundColor = "black"; document.body.appendChild(c.canvas); c.canvas.ctx = c.canvas.getContext("2d"); c.stage = function () {
    var a =
      {}; l(a); a.stage = !0; a.width = c.canvas.width; a.height = c.canvas.height; a.x = 0; a.y = 0; a.parent = void 0; return a
  }(); c.pointer = function () {
    var a = { _x: 0, _y: 0 }; Object.defineProperties(a, {
      x: { get: function () { return a._x / c.scale }, enumerable: !0, configurable: !0 }, y: { get: function () { return a._y / c.scale }, enumerable: !0, configurable: !0 }, centerX: { get: function () { return a.x }, enumerable: !0, configurable: !0 }, centerY: { get: function () { return a.y }, enumerable: !0, configurable: !0 }, position: {
        get: function () { return { x: a.x, y: a.y } }, enumerable: !0,
        configurable: !0
      }
    }); a.isDown = !1; a.isUp = !0; a.tapped = !1; a.downTime = 0; a.elapsedTime = 0; a.press = void 0; a.release = void 0; a.tap = void 0; a.dragSprite = null; a.dragOffsetX = 0; a.dragOffsetY = 0; a.moveHandler = function (b) { a._x = b.pageX - b.target.offsetLeft; a._y = b.pageY - b.target.offsetTop; b.preventDefault() }; a.touchmoveHandler = function (b) { a._x = b.targetTouches[0].pageX - c.canvas.offsetLeft; a._y = b.targetTouches[0].pageY - c.canvas.offsetTop; b.preventDefault() }; a.downHandler = function (b) {
      a._x = b.pageX - b.target.offsetLeft; a._y =
        b.pageY - b.target.offsetTop; a.isDown = !0; a.isUp = !1; a.tapped = !1; a.downTime = Date.now(); a.press && a.press(); b.preventDefault()
    }; a.touchstartHandler = function (b) { a._x = b.targetTouches[0].pageX - c.canvas.offsetLeft; a._y = b.targetTouches[0].pageY - c.canvas.offsetTop; a.isDown = !0; a.isUp = !1; a.tapped = !1; a.downTime = Date.now(); a.press && a.press(); b.preventDefault() }; a.upHandler = function (b) {
      a.elapsedTime = Math.abs(a.downTime - Date.now()); 200 >= a.elapsedTime && (a.tapped = !0, a.tap && a.tap()); a.isUp = !0; a.isDown = !1; a.release && a.release();
      b.preventDefault()
    }; c.canvas.addEventListener("mousemove", a.moveHandler.bind(a), !1); c.canvas.addEventListener("mousedown", a.downHandler.bind(a), !1); window.addEventListener("mouseup", a.upHandler.bind(a), !1); c.canvas.addEventListener("touchmove", a.touchmoveHandler.bind(a), !1); c.canvas.addEventListener("touchstart", a.touchstartHandler.bind(a), !1); window.addEventListener("touchend", a.upHandler.bind(a), !1); c.canvas.style.touchAction = "none"; a.hitTestSprite = function (b) {
      if (b.circular) {
        var c = a.x - (b.gx + b.halfWidth),
          e = a.y - (b.gy + b.halfHeight); b = Math.sqrt(c * c + e * e) < b.radius
      } else { c = b.gx + b.width; e = b.gy; var g = b.gy + b.height; b = a.x > b.gx && a.x < c && a.y > e && a.y < g } return b
    }; a.updateDragAndDrop = function () {
      if (a.isDown) if (null === a.dragSprite) for (var b = c.draggableSprites.length - 1; -1 < b; b--) {
        var h = c.draggableSprites[b]; if (h.draggable && a.hitTestSprite(h)) {
          a.dragOffsetX = a.x - h.gx; a.dragOffsetY = a.y - h.gy; a.dragSprite = h; b = h.parent.children; b.splice(b.indexOf(h), 1); b.push(h); c.draggableSprites.splice(c.draggableSprites.indexOf(h), 1); c.draggableSprites.push(h);
          break
        }
      } else a.dragSprite.x = a.x - a.dragOffsetX, a.dragSprite.y = a.y - a.dragOffsetY; a.isUp && (a.dragSprite = null); c.draggableSprites.some(function (b) { if (b.draggable && a.hitTestSprite(b)) return c.canvas.style.cursor = "pointer", !0; c.canvas.style.cursor = "auto"; return !1 })
    }; return a
  }(); c.key = function () { var a = {}; a.leftArrow = n(37); a.upArrow = n(38); a.rightArrow = n(39); a.downArrow = n(40); a.space = n(32); return a }(); c.buttons = []; c.dragAndDrop = !1; c.draggableSprites = []; c.tweens = []; c.state = void 0; c.load = y || void 0; c.setup = w ||
    void 0; if (void 0 === c.setup) throw Error("Please supply the setup function in the constructor"); c.assetFilePaths = x || void 0; c.paused = !1; c._fps = 60; c._startTime = Date.now(); c._frameDuration = 1E3 / c._fps; c._lag = 0; c.interpolate = !0; c.updateFunctions = []; c.scale = 1; c.start = function () { c.assetFilePaths ? (c.assets.whenLoaded = function () { c.state = void 0; c.setup() }, c.assets.load(c.assetFilePaths), c.load && (c.state = c.load)) : c.setup(); p() }; c.pause = function () { c.paused = !0 }; c.resume = function () { c.paused = !1 }; c.hidePointer = function () {
      c.canvas.style.cursor =
        "none"
    }; c.showPointer = function () { c.canvas.style.cursor = "auto" }; Object.defineProperties(c, { fps: { get: function () { return c._fps }, set: function (a) { c._fps = a; c._startTime = Date.now(); c._frameDuration = 1E3 / c._fps }, enumerable: !0, configurable: !0 }, backgroundColor: { set: function (a) { c.canvas.style.backgroundColor = a }, enumerable: !0, configurable: !0 } }); c.remove = function (a) {
      var b = Array.prototype.slice.call(arguments); if (b[0] instanceof Array) {
        if (b = b[0], 0 < b.length) for (var c = b.length - 1; 0 <= c; c--) {
          var e = b[c]; e.parent.removeChild(e);
          b.splice(b.indexOf(e), 1)
        }
      } else 1 < b.length ? b.forEach(function (a) { a.parent.removeChild(a) }) : b[0].parent.removeChild(b[0])
    }; c.group = function (a) {
      var b = {}; l(b); b.addChild = function (a) { a.parent && a.parent.removeChild(a); a.parent = b; b.children.push(a); b.calculateSize() }; b.removeChild = function (a) { if (a.parent === b) b.children.splice(b.children.indexOf(a), 1); else throw Error(a + "is not a child of " + b); b.calculateSize() }; b.calculateSize = function () {
        0 < b.children.length && (b._newWidth = 0, b._newHeight = 0, b.children.forEach(function (a) {
          a.x +
            a.width > b._newWidth && (b._newWidth = a.x + a.width); a.y + a.height > b._newHeight && (b._newHeight = a.y + a.height)
        }), b.width = b._newWidth, b.height = b._newHeight)
      }; c.stage.addChild(b); a && Array.prototype.slice.call(arguments).forEach(function (a) { b.addChild(a) }); return b
    }; c.rectangle = function (a, b, h, e, g, d, f) {
      var k = {}; l(k); k.mask = !1; k.width = a || 32; k.height = b || 32; k.fillStyle = h || "red"; k.strokeStyle = e || "none"; k.lineWidth = g || 0; k.x = d || 0; k.y = f || 0; c.stage.addChild(k); k.render = function (a) {
        a.strokeStyle = k.strokeStyle; a.lineWidth =
          k.lineWidth; a.fillStyle = k.fillStyle; a.beginPath(); a.rect(-k.width * k.pivotX, -k.height * k.pivotY, k.width, k.height); !0 === k.mask ? a.clip() : ("none" !== k.strokeStyle && a.stroke(), "none" !== k.fillStyle && a.fill())
      }; return k
    }; c.circle = function (a, b, h, e, g, d) {
      var f = {}; l(f); f.mask = !1; f.width = a || 32; f.height = a || 32; f.fillStyle = b || "red"; f.strokeStyle = h || "none"; f.lineWidth = e || "none"; f.x = g || 0; f.y = d || 0; c.stage.addChild(f); r(f); f.render = function (a) {
        a.strokeStyle = f.strokeStyle; a.lineWidth = f.lineWidth; a.fillStyle = f.fillStyle;
        a.beginPath(); a.arc(f.radius + -f.diameter * f.pivotX, f.radius + -f.diameter * f.pivotY, f.radius, 0, 2 * Math.PI, !1); !0 === f.mask ? a.clip() : ("none" !== f.strokeStyle && a.stroke(), "none" !== f.fillStyle && a.fill())
      }; return f
    }; c.line = function (a, b, h, e, g, d) {
      var f = {}; l(f); h || 0 === h || (h = 0); e || 0 === e || (e = 0); g || 0 === g || (g = 32); d || 0 === d || (d = 32); f.ax = h; f.ay = e; f.bx = g; f.by = d; f.strokeStyle = a || "red"; f.lineWidth = b || 1; f.lineJoin = "round"; c.stage.addChild(f); f.render = function (a) {
        a.strokeStyle = f.strokeStyle; a.lineWidth = f.lineWidth; a.lineJoin =
          f.lineJoin; a.beginPath(); a.moveTo(f.ax, f.ay); a.lineTo(f.bx, f.by); "none" !== f.strokeStyle && a.stroke(); "none" !== f.fillStyle && a.fill()
      }; return f
    }; c.text = function (a, b, h, e, g) {
      var d = {}; l(d); d.content = a || "Hello!"; d.font = b || "12px sans-serif"; d.fillStyle = h || "red"; d.textBaseline = "top"; Object.defineProperties(d, { width: { get: function () { return c.canvas.ctx.measureText(d.content).width }, enumerable: !0, configurable: !0 }, height: { get: function () { return c.canvas.ctx.measureText("M").width }, enumerable: !0, configurable: !0 } });
      c.stage.addChild(d); d.x = e || 0; d.y = g || 0; d.render = function (a) { a.strokeStyle = d.strokeStyle; a.lineWidth = d.lineWidth; a.fillStyle = d.fillStyle; 0 === d.width && (d.width = a.measureText(d.content).width); 0 === d.height && (d.height = a.measureText("M").width); a.translate(-d.width * d.pivotX, -d.height * d.pivotY); a.font = d.font; a.textBaseline = d.textBaseline; a.fillText(d.content, 0, 0) }; return d
    }; c.frame = function (a, b, c, e, g) { var d = {}; d.image = a; d.x = b; d.y = c; d.width = e; d.height = g; return d }; c.frames = function (a, b, c, e) {
      var h = {}; h.image =
        a; h.data = b; h.width = c; h.height = e; return h
    }; c.filmstrip = function (a, b, h, e) { var g = c.assets[a].source, d = [], f = g.width / b; g = g.height / h * f; for (var k = 0; k < g; k++) { var l = k % f * b; var m = Math.floor(k / f) * h; e && 0 < e && (l += e + e * k % f, m += e + e * Math.floor(k / f)); d.push([l, m]) } return c.frames(a, d, b, h) }; c.sprite = function (a) {
      var b = {}; if (void 0 === a) throw Error("Sprites require a source"); l(b); b.frames = []; b.loop = !0; b._currentFrame = 0; b.setTexture = function (a) {
        if (a.image) if (a.image && !a.data) {
          if (!(c.assets[a.image].source instanceof Image)) throw Error(a.image +
            " is not an image file"); b.source = c.assets[a.image].source; b.sourceX = a.x; b.sourceY = a.y; b.width = a.width; b.height = a.height; b.sourceWidth = a.width; b.sourceHeight = a.height
        } else a.image && a.data && (b.source = c.assets[a.image].source, b.frames = a.data, b.sourceX = b.frames[0][0], b.sourceY = b.frames[0][1], b.width = a.width, b.height = a.height, b.sourceWidth = a.width, b.sourceHeight = a.height); else a instanceof Array ? (b.frames = a, b.source = c.assets[a[0]].source, b.sourceX = c.assets[a[0]].frame.x, b.sourceY = c.assets[a[0]].frame.y,
          b.width = c.assets[a[0]].frame.w, b.height = c.assets[a[0]].frame.h, b.sourceWidth = c.assets[a[0]].frame.w, b.sourceHeight = c.assets[a[0]].frame.h) : (b.tilesetFrame = c.assets[a], b.source = b.tilesetFrame.source, b.sourceX = b.tilesetFrame.frame.x, b.sourceY = b.tilesetFrame.frame.y, b.width = b.tilesetFrame.frame.w, b.height = b.tilesetFrame.frame.h, b.sourceWidth = b.tilesetFrame.frame.w, b.sourceHeight = b.tilesetFrame.frame.h)
      }; b.setTexture(a); b.gotoAndStop = function (a) {
        if (0 < b.frames.length) b.frames[0] instanceof Array ? (b.sourceX =
          b.frames[a][0], b.sourceY = b.frames[a][1]) : c.assets[b.frames[a]].frame && (b.source = c.assets[b.frames[a]].source, b.sourceX = c.assets[b.frames[a]].frame.x, b.sourceY = c.assets[b.frames[a]].frame.y, b.sourceWidth = c.assets[b.frames[a]].frame.w, b.sourceHeight = c.assets[b.frames[a]].frame.h, b.width = c.assets[b.frames[a]].frame.w, b.height = c.assets[b.frames[a]].frame.h), b._currentFrame = a; else throw Error("Frame number " + a + "doesn't exist");
      }; b.x = 0; b.y = 0; 0 < b.frames.length && (c.addStatePlayer(b), Object.defineProperty(b,
        "currentFrame", { get: function () { return b._currentFrame }, enumerable: !1, configurable: !1 })); c.stage.addChild(b); b.render = function (a) { a.drawImage(b.source, b.sourceX, b.sourceY, b.sourceWidth, b.sourceHeight, -b.width * b.pivotX, -b.height * b.pivotY, b.width, b.height) }; return b
    }; c.button = function (a) { a = c.sprite(a); a.subtype = "button"; t(a); return a }; c.image = function (a) { return c.assets[a] }; c.json = function (a) { return c.assets[a] }; c.addStatePlayer = function (a) {
      function b(b) {
        e(); f = b[0]; k = b[1]; d = k - f; 0 === f && (d += 1, g += 1); 1 ===
          d && (d = 2, g += 1); a.fps || (a.fps = 12); b = 1E3 / a.fps; a.gotoAndStop(f); m || (l = setInterval(c.bind(this), b), m = !0)
      } function c() { g < d ? (a.gotoAndStop(a.currentFrame + 1), g += 1) : a.loop && (a.gotoAndStop(f), g = 1) } function e() { void 0 !== l && !0 === m && (m = !1, d = k = f = g = 0, clearInterval(l)) } var g = 0, d = 0, f = 0, k = 0, l = void 0, m = !1; a.show = function (b) { e(); "string" !== typeof b ? a.gotoAndStop(b) : a.gotoAndStop(a.frames.indexOf(b)) }; a.play = function () { b([0, a.frames.length - 1]) }; a.stop = function () { e(); a.gotoAndStop(a.currentFrame) }; a.playing = m; a.playSequence =
        b
    }; c.render = function (a, b) {
      function h(d) {
        if (d.visible && d.gx < a.width + d.width && d.gx + d.width >= -d.width && d.gy < a.height + d.height && d.gy + d.height >= -d.height) {
          e.save(); c.interpolate ? (d.renderX = void 0 !== d._previousX ? (d.x - d._previousX) * b + d._previousX : d.x, d.renderY = void 0 !== d._previousY ? (d.y - d._previousY) * b + d._previousY : d.y) : (d.renderX = d.x, d.renderY = d.y); e.translate(d.renderX + d.width * d.pivotX, d.renderY + d.height * d.pivotY); e.globalAlpha = d.alpha; e.rotate(d.rotation); e.scale(d.scaleX, d.scaleY); d.shadow && (e.shadowColor =
            d.shadowColor, e.shadowOffsetX = d.shadowOffsetX, e.shadowOffsetY = d.shadowOffsetY, e.shadowBlur = d.shadowBlur); d.blendMode && (e.globalCompositeOperation = d.blendMode); d.render && d.render(e); if (d.children && 0 < d.children.length) { e.translate(-d.width * d.pivotX, -d.height * d.pivotY); for (var f = 0; f < d.children.length; f++)h(d.children[f]) } e.restore()
        }
      } var e = a.ctx; e.clearRect(0, 0, a.width, a.height); for (var g = 0; g < c.stage.children.length; g++)h(c.stage.children[g])
    }; c.assets = {
      toLoad: 0, loaded: 0, imageExtensions: ["png", "jpg",
        "gif", "webp"], fontExtensions: ["ttf", "otf", "ttc", "woff"], audioExtensions: ["mp3", "ogg", "wav", "webm"], jsonExtensions: ["json"], whenLoaded: void 0, load: function (a) {
          console.log("Loading assets..."); var b = this; b.toLoad = a.length; a.forEach(function (a) {
            var e = a.split(".").pop(); if (-1 !== b.imageExtensions.indexOf(e)) { var g = new Image; g.addEventListener("load", function () { g.name = a; b[g.name] = { source: g, frame: { x: 0, y: 0, w: g.width, h: g.height } }; b.loadHandler() }, !1); g.src = a } else if (-1 !== b.fontExtensions.indexOf(e)) {
              e = a.split("/").pop().split(".")[0];
              var d = document.createElement("style"); d.appendChild(document.createTextNode("@font-face {font-family: '" + e + "'; src: url('" + a + "');}")); document.head.appendChild(d); b.loadHandler()
            } else if (-1 !== b.audioExtensions.indexOf(e)) e = c.makeSound(a, b.loadHandler.bind(b)), e.name = a, b[e.name] = e; else if (-1 !== b.jsonExtensions.indexOf(e)) {
              var f = new XMLHttpRequest, h = {}; f.open("GET", a, !0); f.addEventListener("readystatechange", function () {
                200 === f.status && 4 === f.readyState && (h = JSON.parse(f.responseText), h.name = a, b[h.name] =
                  h, h.frames ? b.createTilesetFrames(h, a) : b.loadHandler())
              }); f.send()
            } else console.log("File type not recognized: " + a)
          })
        }, createTilesetFrames: function (a, b) { var c = this, e = b.replace(/[^\/]*$/, ""), g = new Image; g.addEventListener("load", function () { c[e + a.meta.image] = { source: g, frame: { x: 0, y: 0, w: g.width, h: g.height } }; Object.keys(a.frames).forEach(function (b) { c[b] = a.frames[b]; c[b].source = g }); c.loadHandler() }, !1); g.src = e + a.meta.image }, loadHandler: function () {
          this.loaded += 1; console.log(this.loaded); this.toLoad === this.loaded &&
            (this.loaded = this.toLoad = 0, this.whenLoaded())
        }
    }; c.keyboard = n; c.makeDisplayObject = l; void 0 !== GA.plugins && GA.plugins(c); void 0 !== GA.custom && GA.custom(c); return c
}; window.ga = GA.create;